package utils;

/**
 * Utility class to keep track of various paths
 */
public class PathUtils {

	public static String pathToLoginPage = "/login.html";
	public static String pathToHomePage = "/home.html";
    
}